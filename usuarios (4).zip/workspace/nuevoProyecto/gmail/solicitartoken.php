<?php

/*session_start();
require_once '../clases/vendor/autoload.php';
$cliente = new Google_Client();
$cliente->setApplicationName('usuario');
$cliente->setClientId('954652568311-qouj8o5cjhtfqvssginctnqrldv0bava.apps.googleusercontent.com');
$cliente->setClientSecret('vxKUErtrCHXUEud6CslftKMW');
$cliente->setRedirectUri('https://usuarios-sba92.c9users.io/gmail/obtenercredenciales.php');
$cliente->setScopes('https://www.googleapis.com/auth/gmail.compose');
$cliente->setAccessType('offline');
if (!$cliente->getAccessToken()) {
    $auth = $cliente->createAuthUrl();
    header("Location: $auth");
}