<?php

namespace izv\app;

/*
    en esta clase guardo todas las constantes que vamos a necesitar a lo largo de la aplicacion
*/

class App {
    
    const DATABASE = 'nombrebd',
          HOST = 'localhost',    
          PASSWORD = '',
          USER = 'sba92',
          APPLICATION_NAME = 'usuario',
          CLIENT_ID = '954652568311-qouj8o5cjhtfqvssginctnqrldv0bava.apps.googleusercontent.com',
          CLIENT_SECRET = 'vxKUErtrCHXUEud6CslftKMW',
          EMAIL_ORIGIN = 'pepeizv92@gmail.com',
          EMAIL_ALIAS = 'Proyecto primer trimestre',
          EMAIL_TOKEN_FILE = '../gmail/token.conf',
          
          JWT_KEY = 'Proyecto_App_Usuarios',
          USER_SESSION_KEY = 'App_users',
          
          SESSION_NAME = 'APP_USER_SESSION';
}